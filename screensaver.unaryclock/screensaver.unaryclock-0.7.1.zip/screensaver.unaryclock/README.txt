== Unary clock screensaver by Philip Schmiegelt ==

This script is a screensaver which displays the current time in unary format. This means that each number is represented by the number of squares that are illuminated, i.e. you have to count.

An up-to-date copy of the code can be found at the project's GitHub page:
https://github.com/schmiegelt/xbmc.screensaver.unaryclock


== How to run ==
XBMC Frodo features Python screensavers, that is you might have to upgrade XBMC.The screensaver will show up in your list of screensavers.


== Credits ==

Some snippets in the code were taken from:
dershere (https://github.com/dersphere/script.screensaver.test/)
garbear (https://github.com/garbear/unqlocked)
