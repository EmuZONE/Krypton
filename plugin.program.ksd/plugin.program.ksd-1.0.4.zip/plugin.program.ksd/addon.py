#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,os,sys,urllib,time,shutil,re

base_log_path = xbmc.translatePath('special://logpath')
log_file = os.path.join(base_log_path, 'kodi.log')
log_file_copy = os.path.join(base_log_path, 'log_file_copy.log')

def cleanTitle(fName):
    fName = fName.replace("Ä","Ae").replace("Ö","Oe").replace("Ü","Ue").replace("ä","ae").replace("ö","oe").replace("ü","ue").replace("ß","ss")
    return re.sub('[^-a-zA-Z0-9_.() ]+', '', fName).strip()


def DeleteLogFileCopy(log_copy):		
    if os.path.isfile(log_copy):
        try:
            os.remove(log_copy)
        except:
            pass
DeleteLogFileCopy(log_file_copy)

def CopyLogFile(log,log_copy):
    try:
        shutil.copyfile(log, log_copy)
        time.sleep(1)
    except:
        sys.exit(1)
CopyLogFile(log_file,log_file_copy)

def ReadLogFileCopy(log_copy):	
    if os.path.isfile(log_copy):
        try:
            f = open(log_copy,'r')
            for line in f.readlines():

                if 'DVDPlayer: Opening: ' in line:
                    if 'https' in line or 'http' in line  or 'rtmp' in line or 'rtsp' in line or 'mms' in line:
                        try:
                            url = line.split('DVDPlayer: Opening: ')[1]
                            if '|' in url:
                                url = url.split('|')[0]
                        except:
                            pass

                elif 'VideoPlayer: Opening: ' in line:
                    if 'https' in line or 'http' in line  or 'rtmp' in line or 'rtsp' in line or 'mms' in line:
                        try:
                            url = line.split('VideoPlayer: Opening: ')[1]
                            if '|' in url:
                                url = url.split('|')[0]
                        except:
                            pass
            f.close()
            return url
        except:
            sys.exit(1)
    else:
        sys.exit(1)

def FilePathBrowser():	
    path_browser = xbmcgui.Dialog().browse(3,'File Save Path ?', 'files').decode('utf-8')
    if not path_browser == '':
	    return path_browser
    else:
        sys.exit(0)

def FileExtensionReader(url):			
    if '.asf' in url:
        return '.asf'
    elif '.avi' in url:
        return '.avi'
    elif '.mpg' in url:
        return '.mpg'
    elif '.mpeg' in url:
        return '.mpeg'
    elif '.mp4' in url:
        return '.mp4'
    elif '.m4v' in url:
        return '.m4v'
    elif '.mov' in url:
        return '.mov'
    elif '.qt' in url:
        return '.qt'
    elif '.mkv' in url:
        return '.mkv'
    elif '.wmv' in url:
        return '.wmv'
    elif '.webm' in url:
        return '.webm'
    elif '.flv' in url:
        return '.flv'
    elif '.f4v' in url:
        return '.f4v'
    elif '.fla' in url:
        return '.fla'
    elif '.swf' in url:
        return '.swf'
    elif '.3gp' in url:
        return '.3gp'
    elif '.3g2' in url:
        return '.3g2'
    elif '.gif' in url:
        return '.gif'
    elif '.rmvb' in url:
        return '.rmvb'
    elif '.rm' in url:
        return '.rm'
    elif '.rv' in url:
        return '.rv'
    elif '.divx' in url:
        return '.divx'
    elif '.ogv' in url:
        return '.ogv'
    else:
        return '_x.mp4'

def FileDownloader(url,dest):

    dp = xbmcgui.DialogProgress()
    dp.create('Download In Progress','','', '')
    dp.update(0)

    start_time=time.time()

    try:
        urllib.URLopener.version = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        urllib.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, dp, start_time))
    except Exception,e:
        dp.close()
        xbmcgui.Dialog().ok('DOWNLOAD ERROR !',str(e))
        sys.exit(1)

def _pbhook(numblocks, blocksize, filesize, dp, start_time):

        try: 
            percent = min(numblocks * blocksize * 100 / filesize, 100) 
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time)

            if kbps_speed > 0: 
                eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: 
                eta = 0

            kbps_speed = kbps_speed / 1024 
            mbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 

            mbs = '%.02f MB of %.02f MB' % (currently_downloaded, total)
            e = 'Speed: %.02f Mb/s ' % mbps_speed
            ee = 'Remaining Time: %02d:%02d' % divmod(eta, 60)

            dp.update(percent, mbs, e,ee)
        except: 
            percent = 100 
            dp.update(percent)
            dp.close()
            sys.exit(0)
        if dp.iscanceled():
            dp.close()
            sys.exit(1)
		
def SelectExitOptionen(fpath,fname):

    call = xbmcgui.Dialog().select('File Name = ' + fname, ['File rename' , 'File delete', 'Exit'])

    if call == -1:
        sys.exit(0)
	
    elif call == 0:
        keyboard = xbmc.Keyboard(fname, 'New Filename ?')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            try:
                os.rename(os.path.join(fpath,fname),os.path.join(fpath,cleanTitle(keyboard.getText()).strip()))
                xbmcgui.Dialog().ok('Info', 'File rename ok !')
            except:
                xbmcgui.Dialog().ok('Error', 'File rename error !')

    elif call == 1:
        if os.path.isfile(os.path.join(fpath,fname)):
            try:
                os.remove(os.path.join(fpath,fname))
                xbmcgui.Dialog().ok('Info', 'File delete ok !')
            except:
                xbmcgui.Dialog().ok('Error', 'File delete error !')

    elif call == 2:
        sys.exit(0)

file_url = ReadLogFileCopy(log_file_copy)

if not file_url == '':
    file_name = time.strftime("%d%m%Y_%H%M%S")
    file_extension = FileExtensionReader(file_url)
    file_save_path = FilePathBrowser()

    if not file_name == '' and not file_extension == '':
        FileDownloader(file_url,os.path.join(file_save_path,str(file_name + file_extension )))
        SelectExitOptionen(file_save_path,str(file_name + file_extension ))
else:
    sys.exit(1)