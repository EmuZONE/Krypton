# ENDPOINTS
## Videos
### Play a video via ID
####Syntax
```
plugin://plugin.video.vimeo/play/?video_id=[VID]
```
####Example
https://vimeo.com/121465494
```
plugin://plugin.video.vimeo/play/?video_id=121465494
```
