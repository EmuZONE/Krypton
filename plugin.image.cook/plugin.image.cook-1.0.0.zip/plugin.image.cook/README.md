Cooking with Kodi Add-on for Kodi
-------------------------------------
A huge collection of recipes with detailed cooking instructions. 

Setup/Installation: The plugin should be installed through the official Kodi addon repository.

Contact: dtoumbourou@gmail.com
