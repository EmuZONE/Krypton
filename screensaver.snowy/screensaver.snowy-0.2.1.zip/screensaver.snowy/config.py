def FetchDefault():
        return 'snow_town_02b'
def FetchList():
        return [
            ['Transparent Snow 01','snow_transparent_01','http://i.imgur.com/UHtty7s.gif'],
            ['Snowy Forest 01','snow_forest_01c','http://i.imgur.com/VLRGkTr.gif'],
            ['Snowy Forest 02','snow_forest_02b','http://i.imgur.com/qIrt730.gif'],
            #['Snowy Forest 02','snow_forest_03',''],
            ['Snowy Town 01'  ,'snow_town_01c','http://i.imgur.com/ML8oqBU.gif'],
            ['Snowy Town 02'  ,'snow_town_02b','http://i.imgur.com/and9Tcz.gif'],
            #['Snowy Town 03'  ,'snow_town_03',''],
            ['Snowy Town 04'  ,'snow_town_04','http://i.imgur.com/TrxSwqn.gif'],
            ['Snowy Town 05'  ,'snow_town_05','http://i.imgur.com/fzWMVyv.gif'],
            #['Snowy Town 06'  ,'snow_town_06',''],
            #['Snow Town 07'   ,'snow_town_07',''],
            #['Snowfall 01'    ,'snow_01',''],
            ['Snowfall 02'    ,'snow_02','http://i.imgur.com/EcGvdWS.gif'],
            #['Snow Falling 03','snow_03',''],
            #['Scooter Santa'  ,'animated-santa-on-motorcycle','http://i.imgur.com/hv5Apfo.gif'],
            #['Chimney Santa'  ,'santachimney2_e0','http://i.imgur.com/kQxfoHq.gif'],
            ['Swing 01','swing_01','http://i.imgur.com/tCpjBR1.gif'],
            #['','',''],
            #['','',''],
            ['Testing'        ,'',''],
            #['','',''],
            ['Black','Black1.png',''],['Blank','Blank1.png',''] ]
