from xbmcswift2 import Plugin, xbmc, xbmcaddon
from manager import Manager


plugin = Plugin()
manager = Manager()
addon_folder = 'special://home/addons/plugin.audio.100fm'


@plugin.route('/')
def index():
    now = {}
    items = []
    stations = []
    stations.append(manager.get_radio_station())
    stations += manager.get_digital_stations()

    for item in stations:
        if item['now']:
            now = manager.get_now_playing(item['now'])

        items.append({
            'label': plugin.get_string(item['name']),
            'icon': item['icon'],
            'thumbnail': item['icon'],
            'path': item['url'],
            'is_playable': True,
            'info_type': 'music',
            'properties': {
                'fanart_image': xbmcaddon.Addon().getAddonInfo('fanart'),
                'artist_description': u'{0}{1}'.format(plugin.get_string(item['description']),
                                     u'{0} {1} {2} {3}'.format(plugin.get_string(30030), now['name'],
                                                              plugin.get_string(30031), now['artist']) if now else '')
            }
        })

    items.append({
        'label': plugin.get_string(30016),
        'icon': '{0}/resources/media/chart.jpg'.format(addon_folder),
        'thumbnail': '{0}/resources/media/chart.jpg'.format(addon_folder),
        'path': plugin.url_for('show_chart'),
        'is_playable': False,
        'properties': {
            'fanart_image': xbmcaddon.Addon().getAddonInfo('fanart'),
            'artist_description': plugin.get_string(30026)
        }
    })

    items.append({
        'label': plugin.get_string(30017),
        'icon': '{0}/resources/media/archive.jpg'.format(addon_folder),
        'thumbnail': '{0}/resources/media/archive.jpg'.format(addon_folder),
        'path': plugin.url_for('show_archive'),
        'is_playable': False,
        'properties': {
            'fanart_image': xbmcaddon.Addon().getAddonInfo('fanart'),
            'artist_description': plugin.get_string(30027)
        }
    })

    return items


@plugin.cached_route('/chart')
def show_chart():
    items = []

    for idx, item in enumerate(manager.get_chart()):
        items.append({
            'label': u'{0}. {1} {2} {3}'.format(idx + 1, item.title, plugin.get_string(30031), item.artist),
            'icon': item.picture,
            'thumbnail': item.picture,
            'path': item.url,
            'is_playable': True,
            'properties': {
                'fanart_image': xbmcaddon.Addon().getAddonInfo('fanart')
            },
            'info': {
                'Title': item.title,
                'Artist': item.artist
            }
        })

    return items

@plugin.cached_route('/archive')
def show_archive():
    items = []

    for item in manager.get_archive():
        items.append({
            'label': u'{0} {1} {2}'.format(item.title, plugin.get_string(30031), item.artist),
            'icon': item.picture,
            'thumbnail': item.picture,
            'path': item.url,
            'is_playable': True,
            'properties': {
                'fanart_image': xbmcaddon.Addon().getAddonInfo('fanart')
            },
            'info': {
                'Title': item.title,
                'Artist': item.artist
            }
        })

    return items

if __name__ == '__main__':
    plugin.run()
