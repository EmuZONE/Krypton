import json
import re
import requests
from xbmcswift2 import Plugin, xbmc
from bs4 import BeautifulSoup
from song import Song


class Manager(object):
    def __init__(self):
        pass


    def get_now_playing(self, link):
        r = requests.get(link)
        r.encoding = 'UTF-8'
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, 'html5lib')
            # currently no working due to malformed html:
            if link == 'http://www.100fm.co.il/':
                name = soup.select('body table:nth-of-type(1) table table tr:nth-of-type(2)')
                artist = soup.select('body table:nth-of-type(1) table table tr:nth-of-type(3)')
                return {
                    'name': name[0].get_text() if name else '?',
                    'artist': artist[0].get_text() if artist else 'Radius 100FM',
                }
            elif soup.track:
                return {
                    'name': soup.find('name').get_text(),
                    'artist': soup.find('artist').get_text(),
                }


    def get_digital_stations(self):
        """
        Returns digital stations data list
        :return: Array on dictionaries
        """
        with open(xbmc.translatePath('special://home/addons/plugin.audio.100fm/resources/data/digital.json')) as data_file:
            data = json.load(data_file)
        return data


    def get_radio_station(self):
        """
        Returns 100fm radio station object
        :return:
        """
        with open(xbmc.translatePath('special://home/addons/plugin.audio.100fm/resources/data/station.json')) as data_file:
            data = json.load(data_file)
        return data


    def get_chart(self):
        """
        Returns weekly chart's songs
        :return:
        """
        return self.get_songs('http://www.100fm.co.il/jwplayer/jwplayer.aspx')


    def get_archive(self):
        """
        Returns archive songs
        :return:
        """
        return self.get_songs('http://www.100fm.co.il/jwplayer/jwplayerArch.aspx')


    def get_songs(self, url):
        songs = []

        r = requests.get(url)
        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            for item in soup.find_all('td', class_='cssArtist'):
                songs.append(Song('', item.get_text(), '', ''))
            for idx, item in enumerate(soup.find_all('td', class_='cssSong')):
                song = self.find_exceptions(songs[idx].artist, item.get_text())
                songs[idx].title = item.get_text()
                songs[idx].url = 'http://www.fmplayer.co.il/100fmPlayer/{0}.mp3'.format(
                    song[0]['url'] if song else item.get_text().lower().replace(' ', '').replace("'", "").replace(',', ''))
            for idx, item in enumerate(soup.select('img[src^="../download"]')):
                songs[idx].picture = 'http://www.100fm.co.il/{0}'.format(item.get('src').replace('../', ''))

        return songs


    def get_exceptions(self):
        exceptions = []

        r = requests.get('https://spreadsheets.google.com/feeds/list/1C2-ceW3Qp_NKt59T9UejYPStOuqfEcieaZbG3RV20mg/1/public/basic?alt=json')
        for i in r.json()['feed']['entry']:
            matches = re.search('^title: (.+), artist: (.+), file: (.+)$', i['content']['$t'])
            if matches:
                exceptions.append({
                    "artist": matches.group(2),
                    "title": matches.group(1),
                    "url": matches.group(3)
                })

        return exceptions


    def find_exceptions(self, artist, title):
        return [item for item in self.get_exceptions() if item['artist'] == artist and item['title'] == title]
