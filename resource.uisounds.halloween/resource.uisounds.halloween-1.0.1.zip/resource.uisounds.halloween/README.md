 UI Sounds for the Kodi Hallowe'en skin.
