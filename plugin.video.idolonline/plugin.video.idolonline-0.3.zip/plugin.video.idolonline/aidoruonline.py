import cookielib, urllib, urllib2
import util
import hashlib, base64
import os, sys, xbmcaddon, xbmc

sysarg=str(sys.argv[1])
ADDON_ID='plugin.video.idolonline'
addon=xbmcaddon.Addon(id=ADDON_ID)
home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

profileDir = xbmcaddon.Addon().getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir)
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

site="https://aidoru-online.org/"

cj = cookielib.CookieJar()  
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

def login(username, password):
    headers = [('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'),
           ('Accept', '*/*'),
           ('Connection', 'keep-alive'),
           ('origin', 'https://aidoru-online.org'),
           ('referer', 'https://aidoru-online.org/login.php?type=login')]

    opener.addheaders = headers
    opener.open('https://aidoru-online.org/login.php')

    for cookie in cj:
        if cookie.name=='csrfp_token':
            csrfp_token=cookie.value

    login_data = urllib.urlencode({'username' : username, 'password' : password, 'do' : 'login', 'language' : '', 'csrfp_token' : csrfp_token})
    opener.open('https://aidoru-online.org/login.php?type=login', login_data)
    
    resp=opener.open('https://aidoru-online.org')
    
    if len(resp.read())>0:
        return True
    else:
        return False
        
def getTorrents(pcat="Show+AlL", typ="name", scat="", subbed="", fl="", resd="", p="0", searchstr="", deadlive=0):
    resp=opener.open("https://aidoru-online.org/get_ttable.php?pcat="+str(pcat)+"&typ="+str(typ)+"&scat="+str(scat)+"&subbed="+str(subbed)+"&fl="+str(fl)+"&resd="+str(resd)+"&p="+str(p)+"&searchstr="+str(searchstr)+"&deadlive="+str(deadlive))
    content=resp.read()

    ret=[]
    
    torrent_list=util.extractAll(content, "<tr class='t-row'>", "</tr>")
    
    for details in torrent_list:
        column=util.extractAll(details, '<td', '</td')
        
        name="["+util.extract(column[0], '">', '</a>')+" | "+util.extract(column[5]+"<", ">", "<")+"] - "+util.extract(column[1], 'title="', '"')
        torrent=site+util.extract(column[2], '<a href="', '"')
        file=torrent.replace("https://aidoru-online.org/download.php?id=1", "")+".torrent"
        
        ret.append({"name":name, "torrent":torrent, "file": file})
        
        
        
    return ret

def downloadTorrent(torrent, file):
    with open(xbmc.translatePath(os.path.join(profileDir, '', file)), "wb") as f:
        f.write(opener.open(torrent).read())
        
    return xbmc.translatePath(os.path.join(profileDir, '', file))