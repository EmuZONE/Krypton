### PureRadio Audio Plugin.

This plugin enables the playback of the PureRadio audio stream, which can be set in different qualities using different bitrates. Also a selection of podcast, hosted on Spreaker, are available for instant playback.

Visit us at PureRadio (http://www.pureradio.one) or Facebook (https://facebook/pureradio.one).
