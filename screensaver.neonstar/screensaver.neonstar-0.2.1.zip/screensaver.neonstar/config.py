def FetchDefault():
        return 'Neonb'
def FetchList():
        return [
            ['Neon 01 Happy'  ,'Neonb','http://i.imgur.com/S7BguLT.gif'],
            ['Neon 02 Sad'    ,'Neon_2b','http://i.imgur.com/BS6BRR6.gif'],
            ['Neon 03 Blank'  ,'Neon_3b','http://i.imgur.com/j6qA4wv.gif'],
            #['','',''],
            #['','',''],
            ['Testing'        ,'',''],
            #['','',''],
            ['Black','Black1.png',''],['Blank','Blank1.png',''] ]
