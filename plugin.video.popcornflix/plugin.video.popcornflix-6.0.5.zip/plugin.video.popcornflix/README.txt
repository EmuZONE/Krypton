plugin.video.popcornflix================

Kodi Addon for popcornflix website

Version 6.0.4 Website changes
Version 6.0.3 Added "Add to Library"
Version 6.0.1 Isengard version - separate scraper
Version 5.0.10 fix for unicode in url
Version 5.0.9 Added metadata and view select, version bump
Version 1.0.8 Fix for bitrate range change and website changes
Version 1.0.7 Fix for change in bitrate range
Version 1.0.6 Added bitrate setting
Version 1.0.5 Website change
Version 1.0.4 Fix stupid shortcut for US site so videos play on International sites
version 1.0.2 initial release

