 UI Sounds for the Kodi Super Mario skin.
