plugin.program.sendtoaxel
=========================

A tool to help in the process of using Axel Downloader.
