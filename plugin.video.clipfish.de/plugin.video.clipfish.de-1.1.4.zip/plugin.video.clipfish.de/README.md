![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.clipfish.de/icon.png)
# **Links:**

* [Clipfish](www.clipfish.de/)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) 

# **Changelog:**

## **1.1.2**

* Script error because of missing images in the API
* added alternative images, if posters are missing for movies
* kodion

## **1.1.1**

* improved playback. Working with the id of the video, so videos stay watched

## **1.1.0**

* improved support for Gotham, Helix and Isengard
* show seconds (Gotham)


# **Images:**
![](http://i.imgur.com/xltujOj.png)
