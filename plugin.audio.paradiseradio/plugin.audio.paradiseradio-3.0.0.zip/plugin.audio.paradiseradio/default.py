import urllib2,urllib,cgi, re, os
import urlparse
import HTMLParser
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs



          

    
addon = xbmcaddon.Addon('plugin.audio.paradiseradio')
addonname = addon.getAddonInfo('name')
#icon = addon.getAddonInfo('icon')
addon_id = 'plugin.audio.paradiseradio'
selfAddon = xbmcaddon.Addon(id=addon_id)
profile_path =  xbmc.translatePath(selfAddon.getAddonInfo('profile'))
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8')) 
icon = os.path.join(home, 'icon.png')
FANART = os.path.join(home, 'fanart.jpg')

addonDir = addon.getAddonInfo('path').decode("utf-8")
libDir = os.path.join(addonDir, 'resources', 'lib')
profile = xbmc.translatePath(addon.getAddonInfo('profile').decode('utf-8'))
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))
favorites = os.path.join(profile, 'favorites')
history = os.path.join(profile, 'history')
 


addon_handle = int(sys.argv[1])
pluginhandle = int(sys.argv[1])

URL_HI   = 'http://shoutcast.paradiseradio.org:8390'
URL_LO   = 'http://shoutcast.paradiseradio.org:8620'



class NoRedirection(urllib2.HTTPErrorProcessor):
   def http_response(self, request, response):
       return response
   https_response = http_response





def addLink(name, url, mode, iconimage):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addDir(name,url,mode,iconimage,fanart,description,genre,date,credits,isItFolder=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        if date == '':
            date = None
        else:
            description += '\n\nDate: %s' %date
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date, "credits": credits })
        liz.setProperty("Fanart_Image", fanart)

        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isItFolder)
        return ok







def GetHTML(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link




def Addtypes():
    addDir('Listen Paradise Radio [HI]' ,URL_HI,5,icon ,  FANART,'','','','')
    addDir('Listen Paradise Radio [LO]' ,URL_LO,5,icon ,  FANART,'','','','')
    addDir('Request Song' ,'Request',2,icon ,  FANART,'','','','')
    addDir('Search & Request' ,'Request',6,icon ,  FANART,'','','','')
    return






def Request(url=None):
    addDir('0 - 9' ,'0%20-%209',3,icon ,  FANART,'','','','')
    addDir('A' ,'a',3,icon ,  FANART,'','','','')
    addDir('B' ,'b',3,icon ,  FANART,'','','','')
    addDir('C' ,'c',3,icon ,  FANART,'','','','')
    addDir('D' ,'d',3,icon ,  FANART,'','','','')
    addDir('E' ,'e',3,icon ,  FANART,'','','','')
    addDir('F' ,'f',3,icon ,  FANART,'','','','')
    addDir('G' ,'g',3,icon ,  FANART,'','','','')
    addDir('H' ,'h',3,icon ,  FANART,'','','','')
    addDir('I' ,'i',3,icon ,  FANART,'','','','')
    addDir('J' ,'j',3,icon ,  FANART,'','','','')
    addDir('K' ,'k',3,icon ,  FANART,'','','','')
    addDir('L' ,'l',3,icon ,  FANART,'','','','')
    addDir('M' ,'m',3,icon ,  FANART,'','','','')
    addDir('N' ,'n',3,icon ,  FANART,'','','','')
    addDir('O' ,'o',3,icon ,  FANART,'','','','')
    addDir('P' ,'p',3,icon ,  FANART,'','','','')
    addDir('Q' ,'q',3,icon ,  FANART,'','','','')
    addDir('R' ,'r',3,icon ,  FANART,'','','','')
    addDir('S' ,'s',3,icon ,  FANART,'','','','')
    addDir('T' ,'t',3,icon ,  FANART,'','','','')
    addDir('U' ,'u',3,icon ,  FANART,'','','','')
    addDir('V' ,'v',3,icon ,  FANART,'','','','')
    addDir('W' ,'w',3,icon ,  FANART,'','','','')
    addDir('X' ,'x',3,icon ,  FANART,'','','','')
    addDir('Y' ,'y',3,icon ,  FANART,'','','','')
    addDir('Z' ,'z',3,icon ,  FANART,'','','','')



def keyboard(url=None):
    keyboard = xbmc.Keyboard('', 'Search Artist:', False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query == '' :
           return False
        else:
           Playlist(query)
           



def PutRequest(url):
    req_regex = '<title>(.*?)</title>'
    url = 'http://www.paradiseradio.org/sam/web/request.php?songID='+url
    request = GetHTML(url)
    match = re.compile(req_regex).findall(request)
    for dialogtext in match:
        if 'error' in request :
            match = re.compile('<h2 class=\"error\">(.*?)</h2>').findall(request)
            for status in match:
                dialog = xbmcgui.Dialog()
                dialog.ok(dialogtext, status, "Paradise Radio")
        if 'success' in request :
            match = re.compile('<h2 class=\"success\">(.*?)</h2>').findall(request)
            for status in match:
                dialog = xbmcgui.Dialog()
                dialog.ok(dialogtext, status, "Paradise Radio")

                





def Playlist(url):
    xml_regex = '<artist>(.*?)</artist>\s*<title>(.*?)</title>\s*<id>(.*?)</id>'
    xmlurl = 'http://www.paradiseradio.org/sam/web/playlist.php?search=&limit=9999&character='+url
    print xmlurl
    xml = GetHTML(xmlurl)
    match = re.compile(xml_regex).findall(xml)
    for artist, title, songid in match:
        addDir(artist+' - '+title ,songid,4,icon ,  FANART,'','','','')
    



def getResponse(url):
    try:
        response = urllib2.urlopen(url, timeout=200)
        if response and response.getcode() == 200:
            return response
        else :
            return False
    except:
        return False
    








def playparadise(url):
    name = 'Paradise Radio'
    listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ) )

    xbmc.Player( xbmc.PLAYER_CORE_AUTO ).play( url, listitem)

    
        





def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
				
	return param



params=get_params()
url=None
name=None
mode=None
linkType=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass


args = cgi.parse_qs(sys.argv[2][1:])
linkType=''
try:
	linkType=args.get('linkType', '')[0]
except:
	pass


print 	mode,url,linkType

try:
	if mode==None or url==None or len(url)<1:
		print "InAddTypes"
		Addtypes()
        elif mode==2 :
		Request(url)
	elif mode==3 :
		Playlist(url)
	elif mode==4 :
		PutRequest(url)
	elif mode==5 :
		playparadise(url)
	elif mode==6 :
		keyboard(url)
		
		


        

    
	

except:
	print 'somethingwrong'
	traceback.print_exc(file=sys.stdout)
	

if not ( (mode==5 or mode==4 or mode==9 or mode==11 or mode==15 or mode==21 or mode==22 or mode==27 or mode==33 or mode==35 or mode==37 or mode==40 or mode==42 or mode==0)  )  :
	if mode==144:
		xbmcplugin.endOfDirectory(int(sys.argv[1]),updateListing=True)
	else:
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
