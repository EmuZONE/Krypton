from api import API

api = API()

# print str(api.get_channels())
# print api.get_playlists('http://eco99fm.maariv.co.il/music_channels/channel.aspx?SCid=30')
print api.get_playlist('http://eco99fm.maariv.co.il/music_channel/2704.aspx')