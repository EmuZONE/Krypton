import xbmcgui
from xbmc import executebuiltin
from xbmcaddon import Addon

ADDON = Addon()


# ADDON_ID = ADDON.getAddonInfo('id')
# ADDON_NAME = ADDON.getAddonInfo('name')


class ArtworkWindow(xbmcgui.WindowDialog):
    def __init__(self):
        self.setCoordinateResolution(0)  # 1920x1080

        # overlay
        self.overlay = xbmcgui.ControlImage(0, 0, 1920, 1080,
                                            'special://home/addons/plugin.audio.99fm-playlists/resources/media/00000066.png')

        # strip
        strip = xbmcgui.ControlImage(0, 300, 1920, 500,
                                            'special://home/addons/plugin.audio.99fm-playlists/resources/media/00000033.png')

        # 99fm logo
        logo = xbmcgui.ControlImage(300, 250, 356, 189,
                                         'special://home/addons/plugin.audio.99fm-playlists/resources/media/99fm.png')
        # channel name
        channel = xbmcgui.ControlLabel(20, 450, 1005, 50, '[B]$INFO[MusicPlayer.Title][/B]',
                                            alignment=1, textColor='0xFF00B5B4')

        # channel description
        description = xbmcgui.ControlLabel(20, 500, 1160, 50, '$INFO[MusicPlayer.Artist]',
                                           alignment=1)

        time = xbmcgui.ControlLabel(20, 550, 1160, 50, '$INFO[Player.Time] / $INFO[Player.Duration]',
                                                alignment=1, textColor='0xFF777777')

        # shadow
        cover_shadow = xbmcgui.ControlImage(1185, 240, 620, 620,
                                            'special://home/addons/plugin.audio.99fm-playlists/resources/media/box-shadow.png'
                                            )

        # album art
        self.cover = xbmcgui.ControlImage(1200, 250, 600, 600,
                                          ''
                                          )

        spinner = xbmcgui.ControlImage(1480, 520, 54, 55,
                                       'special://home/addons/plugin.audio.99fm-playlists/resources/media/spinner.gif'
                                       )

        # song name
        self.song = xbmcgui.ControlLabel(20, 700, 1165, 40, 'Song Name',
                                                alignment=1)


        # artist
        self.artist = xbmcgui.ControlLabel(20, 740, 1165, 40, 'Artist Name',
                                                alignment=1, textColor='0xFFEFEFEF')

        self.btn_close = xbmcgui.ControlButton(1400, 870, 200, 50, ADDON.getLocalizedString(32010).encode('utf-8'),
                                               focusTexture='special://home/addons/plugin.audio.99fm-playlists/resources/media/00B5B466.png',
                                               textColor='0xFFFFFFFF',
                                               focusedColor='0xFFFFFFFF',
                                               noFocusTexture='special://home/addons/plugin.audio.99fm-playlists/resources/media/00B5B4AA.png',
                                               alignment=2)

        # add all controls:
        self.addControls((self.overlay, strip, logo, channel, description,
                          cover_shadow, spinner, self.cover, self.song, self.artist, time, self.btn_close))

        # set animations:
        channel.setAnimations([('WindowOpen', 'effect=zoom end=115')])
        self.setFocus(self.btn_close)

    def onAction(self, action):
        if action == xbmcgui.ACTION_BACKSPACE or action == xbmcgui.ACTION_PARENT_DIR or \
                        action == xbmcgui.ACTION_PREVIOUS_MENU or action == xbmcgui.ACTION_NAV_BACK:
            self.close()

    def onControl(self, control):
        if control == self.btn_close:
            executebuiltin('PlayerControl(Stop)')
            self.close()
