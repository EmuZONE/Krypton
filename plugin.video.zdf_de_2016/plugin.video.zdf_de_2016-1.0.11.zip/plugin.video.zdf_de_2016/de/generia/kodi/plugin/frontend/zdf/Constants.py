
class Constants(object):
    baseUrl = 'https://www.zdf.de'
    apiBaseUrl = 'https://api.zdf.de'
    apiContentUrl = apiBaseUrl + '/content/documents'
    showsAzUrl = '/sendungen-a-z'
