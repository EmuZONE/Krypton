import gui,xbmc,urllib,urllib2,xbmcaddon,os,time,gzip
import source,utils,hashlib

addon_id = 'script.apollo.tvguide'
Addon = xbmcaddon.Addon(addon_id)

addonFolder = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon_id))
if not os.path.exists(addonFolder):
	os.makedirs(os.path.join(addonFolder))

# Get guide.xml
xmltvFile = xbmc.translatePath(os.path.join(addonFolder, 'custom.xml'))
xmltvGzFile = xbmc.translatePath(os.path.join(addonFolder, 'guide.xml.gz'))
if not os.path.exists(xmltvFile) or str(urllib2.urlopen("http://static.apollogroup.tv/guide.xml.md5").read()) <> str(hashlib.md5(open(xmltvFile, 'rb').read()).hexdigest()):
	try:
		os.remove(xmltvGzFile)
	except:
		pass
	try:
		os.remove(xbmc.translatePath(os.path.join(addonFolder, 'master.db')))
	except:
		pass
	xbmc.executebuiltin('Notification(Apollo Group,"Please wait, loading TV Guide.", {0}, {1})'.format(5000,os.path.join('special://home',"addons",addon_id ,"icon.png")))
	urllib.urlretrieve("http://static.apollogroup.tv/guide.xml.gz", xmltvGzFile)
	inF = gzip.open(xmltvGzFile, 'rb')
	outF = open(xmltvFile, 'wb')
	outF.write(inF.read())
	inF.close()
	outF.close()
	utils.set_setting(addon_id, 'xmltv.file', xmltvFile)

	# Get addons.ini
	addonsFile = xbmc.translatePath(os.path.join(addonFolder, 'addons.ini'))
	urllib.urlretrieve("http://static.apollogroup.tv/addons.ini", addonsFile)

	# Get categories.ini
	categoriesFile = xbmc.translatePath(os.path.join(addonFolder, 'categories.ini'))
	urllib.urlretrieve("http://static.apollogroup.tv/categories.ini", categoriesFile)
	utils.set_setting(addon_id, 'categories.ini.file', categoriesFile)

if 1:
	w = gui.TVGuide()
	w.doModal()
	del w
#except:
#	pass