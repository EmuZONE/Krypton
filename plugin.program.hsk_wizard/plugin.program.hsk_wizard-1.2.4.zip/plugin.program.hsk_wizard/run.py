#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,sys

_addon_ = xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')

server_data_url = 'http://hsk.kodiman.net/hsk/wizard_data.txt'

base_settings_array = []
base_settings_array = ['[COLOR blue]Addon Settings[/COLOR]', 'HSK Wizard' , 'Lade Backup zip', 'Sichere Backup zip', 'Aktiviere Addons', 'Update Addons', 'Repo Tester','Datei Downloader', 'Lese Log', 'WTPT Cleaner', '[COLOR red]Frischer Start[/COLOR]']

android_settings_array = []
if xbmc.getCondVisibility('system.platform.android'):
    android_settings_array = ['[COLOR red]APK Installer[/COLOR]'] 

call = xbmcgui.Dialog().select('[COLOR blue]HSK WIZARD[/COLOR]', base_settings_array + android_settings_array)
if call == -1:
    sys.exit(0)

if call == 0:
    xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')')

if call == 1:
    import wizard
    wizard.run(server_data_url)

if call == 2:
    import extractor
    extractor.run()

if call == 3:
    import zipper
    zipper.run()

if call == 4:
    import activator
    activator.run()

if call == 5:
    import update
    update.run()

if call == 6:
    import checker
    checker.run()

if call == 7:
    import downloader
    downloader.run()

if call == 8:
    import log
    log.run()

if call == 9:
    import wtptcleaner
    wtptcleaner.run()

if call == 10:
    import cleaner
    cleaner.run()

if call == 11:
    import apk
    apk.run(server_data_url)

sys.exit(0)