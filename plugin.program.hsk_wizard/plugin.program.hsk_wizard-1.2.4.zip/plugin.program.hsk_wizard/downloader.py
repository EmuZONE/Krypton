#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,urllib2,socket,urlparse,posixpath,math,time,datetime

_addon_ = xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')
		
def keyboard_filename(file_name):		
    keyboard = xbmc.Keyboard(file_name, 'filename.xxx ?')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        return keyboard.getText().decode('utf-8')
    else:
        return ''
		
def delete_file(file):
    if os.path.exists(file):
        try:
            os.remove(file)
        except:
            pass

def download(file_download_url,file_download_path):

    dp = xbmcgui.DialogProgress()

    def convert_size(size):
	    if (size == 0):
		    return '0B'
	    units = (' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB')
	    i = int(math.floor(math.log(size,1024)))
	    p = math.pow(1024,i)
	    size = "%.3f" % round((size/p),3)
	    return'{}{}'.format(size,units[i])

    try:
        socket.setdefaulttimeout(30)
        req= urllib2.Request(file_download_url)
        resp = urllib2.urlopen(req,timeout=30)

        total_size = int(0)
        downloaded = int(0)

        file_name =''
        try:file_name = resp.info().getheaders('Content-Disposition')[0].split('filename=')[1]
        except IndexError:file_name = keyboard_filename(urllib2.unquote(posixpath.basename(urlparse.urlsplit(resp.url).path)))
        if file_name:full_file_path = os.path.join(file_download_path,file_name)
        else:sys.exit(0)

        try:total_size = int(resp.info().getheaders("Content-Length")[0])
        except IndexError:sys.exit(0)

        dp.create('FILE DOWNLOADER','Downloade Datei !','Bitte warten ...')
        dp.update(0)

        CHUNK = 8 * 1024
        start_time = time.time();xbmc.sleep(1)
        with open(full_file_path,'wb') as fw:
            while True:

                chunk = resp.read(CHUNK)
                downloaded += len(chunk)

                if not chunk: break
                fw.write(chunk)

                try:
                    percent = min(downloaded * 100 / total_size, 100)
                    speed = (downloaded / (time.time() - start_time))
                    if speed > 0: remaining_sec = ((total_size - downloaded) / speed)
                    else: remaining_sec = 0
                    s = 'Geladen: %s von %s - ( %s%% )'% (convert_size(downloaded),convert_size(total_size),str(percent))
                    ss = 'Geschwindigkeit: %s/s' % (convert_size(speed))
                    sss = 'Verbleibende Zeit: %s' % datetime.timedelta(seconds=remaining_sec)
                    dp.update(percent,s,ss,sss)
                except:
                    dp.update(100)
                    dp.close()

                if dp.iscanceled():
                    resp.close()
                    fw.close()
                    dp.close()
                    delete_file(full_file_path)
                    sys.exit(0)

        dp.update(100)
        resp.close()
        fw.close()		
        dp.close()

    except urllib2.HTTPError, e:
        xbmcgui.Dialog().ok('HTTP ERROR:',str(e.code))
        sys.exit(0)
    except urllib2.URLError, e:
        xbmcgui.Dialog().ok('URL ERROR:',str(e.reason))
        sys.exit(0)
    except socket.timeout, e:
        xbmcgui.Dialog().ok('SOCKET TIMEOUT ERROR:',str(e))
        sys.exit(0)

def run ():

    file_download_url_settings = _addon_.getSetting('file_download_url')
    file_download_path_settings = _addon_.getSetting('file_download_path')
    if not file_download_path_settings or not file_download_url_settings :
        xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')')
        sys.exit(0)

    _file_download_url_ = file_download_url_settings.decode('utf-8')
    _file_download_path_ = en_de_code_path(xbmc.translatePath(file_download_path_settings))

    delete_file(_file_download_path_)

    download(_file_download_url_,_file_download_path_)