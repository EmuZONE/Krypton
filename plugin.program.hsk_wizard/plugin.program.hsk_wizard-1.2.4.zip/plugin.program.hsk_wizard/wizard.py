#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,urllib2,socket,zipfile,re,math,time,datetime
from sqlite3 import dbapi2 as db_lib

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_addon_ = xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')
_addon_path_ = en_de_code_path(xbmc.translatePath(_addon_.getAddonInfo('path')))

password_settings = _addon_.getSetting('wizard_download_password')
if not password_settings:
    xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')')
    sys.exit(0)

_sys_build_version_ = xbmc.getInfoLabel('System.BuildVersion')
_backup_zip_path_ = os.path.join(_addon_path_,'resources','data')
_home_path_ = en_de_code_path(xbmc.translatePath('special://home/'))
_database_path_ = en_de_code_path(xbmc.translatePath('special://profile/Database'))

def get_server_data(server_url):
    try:
        server_data = ''
        socket.setdefaulttimeout(30)
        req= urllib2.Request(server_url)
        resp = urllib2.urlopen(req,timeout=30)
        server_data = resp.read()
        resp.close()
        return server_data
    except urllib2.HTTPError, e:
        xbmcgui.Dialog().ok('HTTP ERROR:',str(e.code))
        sys.exit(0)
    except urllib2.URLError, e:
        xbmcgui.Dialog().ok('URL ERROR:',str(e.reason))
        sys.exit(0)
    except socket.timeout, e:
        xbmcgui.Dialog().ok('SOCKET TIMEOUT ERROR:',str(e))
        sys.exit(0)

def get_build_download_url(server_data,sys_build_version):
    if not server_data:
        sys.exit(0)
    server_data = server_data.replace("'",'"')
    for build_version,download_url in re.compile('build-version="(.*?)"[\s\S].*?build-download-url="(.*?)"',re.DOTALL).findall(server_data):
        if sys_build_version.startswith(build_version):
            return download_url
            break

def delete_file(file):
    if os.path.exists(file):
        try:
            os.remove(file)
        except:
            pass
	
def delete_old_files(path,save_filename):
    if os.path.exists(path):
        for root, dirs, files in os.walk(path,topdown=False,onerror=None,followlinks=True):
            for name in files:
                if not name in save_filename:
                    full_file_path = os.path.join(root,name)
                    if os.path.exists(full_file_path):
                        try:
                            os.remove(full_file_path)
                        except:
                            pass

def clean_data(home_path,addon,addon_id):
    dp = xbmcgui.DialogProgress()
    dp.create('CLEAN DATA','Bereinige Daten !','Bitte warten ...')
    dp.update(0)
    filesList = []
    save_list_array = []
    try:
        skin_id = xbmc.getSkinDir()
        if not addon_id == '':
            save_list_array.append(addon_id)
        if not skin_id == '':
            save_list_array.append(skin_id)
        if addon.getSetting('save_old_favourites') == 'true':
            save_list_array.append('favourites.xml')
        save_list_array.append('Addons26.db')
        save_list_array.append('Addons27.db')
        save_list_array.append('Textures13.db')
        save_list_array.append('commoncache.db')
        save_list_array.append('metadata.album.universal')
        save_list_array.append('metadata.artists.universal')
        save_list_array.append('metadata.common.musicbrainz.org')
        save_list_array.append('metadata.common.imdb.com')
        filesList = list(os.walk(home_path,topdown=False,onerror=None,followlinks=True))
        count = int(0)
        filesCount = float(0)
        filesCount += float(len(filesList))
        for pathentry in filesList:
            for dir in pathentry[1]:
                path = os.path.join(pathentry[0],dir)
                if not any((x in path for x in save_list_array)):
                    if os.path.islink(path):
                        try:
                            os.unlink(path)
                        except:
                            pass
                    else:
                        try:
                            os.rmdir(path)
                        except:
                            pass
            for file in pathentry[2]:
                path = os.path.join(pathentry[0],file)
                if not any((x in path for x in save_list_array)):
                    try:
                        os.unlink(path)
                    except:
                        pass
            count += 1
            update = count / filesCount * 100
            dp.update(int(update))
            if dp.iscanceled():
                dp.close()
                sys.exit(0)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok('ERROR !', str(e))
        sys.exit(0)
    dp.close()

def resume_download(file_download_url,file_download_path):

    dp = xbmcgui.DialogProgress()
    dp.create('BACKUP DOWNLOADER','Downloade Backup !','Bitte warten ...')
    dp.update(0)

    def convert_size(size):
	    if (size == 0):
		    return '0B'
	    units = (' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB')
	    i = int(math.floor(math.log(size,1024)))
	    p = math.pow(1024,i)
	    size = "%.3f" % round((size/p),3)
	    return'{}{}'.format(size,units[i])

    try:
        socket.setdefaulttimeout(30)
        req= urllib2.Request(file_download_url)
        resp = urllib2.urlopen(req,timeout=30)

        total_size = int(0)
        downloaded = int(0)
        existent_size = int(0)

        try:file_name = resp.info().getheaders('Content-Disposition')[0].split('filename=')[1].strip()
        except IndexError:sys.exit(0)

        delete_old_files(file_download_path,file_name)
        full_file_path = os.path.join(file_download_path,file_name)

        try:total_size = int(resp.info().getheaders("Content-Length")[0])
        except IndexError:sys.exit(0)

        open_file_mode = 'wb'
        if os.path.exists(full_file_path):

            existent_size = int(os.path.getsize(full_file_path))
            if existent_size < total_size and existent_size != total_size:
                downloaded = existent_size

                resp.close()

                socket.setdefaulttimeout(30)
                req= urllib2.Request(file_download_url)
                req.add_header('Accept-Ranges','bytes')
                req.add_header('Range','bytes=%s-%s' % (existent_size, total_size))
                resp = urllib2.urlopen(req,timeout=30)

                try:resume_size = int(resp.info().getheaders("Content-Length")[0])
                except IndexError:sys.exit(0)

                if resume_size < total_size and resume_size != total_size:
                    open_file_mode = 'ab+'

        CHUNK = 8 * 1024
        currently_downloaded = int(0)
        start_time = time.time();xbmc.sleep(1)
        with open(full_file_path,open_file_mode) as fw:
            while True:

                chunk = resp.read(CHUNK)
                downloaded += len(chunk)
                currently_downloaded += len(chunk)

                if not chunk: break
                fw.write(chunk)

                try:
                    percent = min(downloaded * 100 / total_size, 100)
                    speed = (currently_downloaded / (time.time() - start_time))
                    if speed > 0: remaining_sec = ((total_size - downloaded) / speed)
                    else: remaining_sec = 0
                    s = 'Geladen: %s von %s - ( %s%% )'% (convert_size(downloaded),convert_size(total_size),str(percent))
                    ss = 'Geschwindigkeit: %s/s' % (convert_size(speed))
                    sss = 'Verbleibende Zeit: %s' % datetime.timedelta(seconds=remaining_sec)
                    dp.update(percent,s,ss,sss)
                except:
                    dp.update(100)
                    dp.close()

                if dp.iscanceled():
                    resp.close()
                    fw.close()
                    dp.close()
                    sys.exit(0)

        dp.update(100)
        resp.close()
        fw.close()		
        dp.close()
        return full_file_path

    except urllib2.HTTPError, e:
        xbmcgui.Dialog().ok('HTTP ERROR:',str(e.code))
        sys.exit(0)
    except urllib2.URLError, e:
        xbmcgui.Dialog().ok('URL ERROR:',str(e.reason))
        sys.exit(0)
    except socket.timeout, e:
        xbmcgui.Dialog().ok('SOCKET TIMEOUT ERROR:',str(e))
        sys.exit(0)

def check_zipfile(zip_file_full_path):
    if os.path.exists(zip_file_full_path):
        try:
           return zipfile.ZipFile(zip_file_full_path,mode='r',compression=zipfile.ZIP_STORED,allowZip64=True)
        except zipfile.BadZipfile:
            return 'No zip file !'
    else:
        return 'No zip file !'

def extract_zip(zipfile,zip_file_full_path,home_path,addon,addon_id,zip_pwd=None):
    if not os.path.exists(zip_file_full_path):
        xbmcgui.Dialog().ok('ZIP EXTRACT ERROR !','File not found !')
        sys.exit(0) 
    dp = xbmcgui.DialogProgress()
    dp.create('BACKUP EXTRACTOR','Entpacke Daten !','Bitte warten ...')
    dp.update(0)
    count = int(0)
    try:
        nFiles = float(len(zipfile.infolist()))
        for item in zipfile.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            try:
                if addon.getSetting('save_old_favourites') == 'true':
                    if addon_id not in item.filename and not 'favourites.xml' in item.filename:
                        zipfile.extract(item,path=home_path,pwd=zip_pwd)
                else:
                    if addon_id not in item.filename:
                        zipfile.extract(item,path=home_path,pwd=zip_pwd)
            except:
                pass
            if dp.iscanceled():
                dp.close()
                sys.exit(0)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok('ZIP EXTRACT ERROR !',str(e))
        sys.exit(0)
    dp.close()
    zipfile.close()

def wizard_activator(database_path,home_path,sys_build_version,addon_id):
    if float(sys_build_version[0:4]) >= 17.0:
        conn = db_lib.connect(os.path.join(database_path,'Addons27.db'))
        conn.text_factory = str
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)',addon_id)
        conn.commit()

def get_platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    if xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    if xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    if xbmc.getCondVisibility('system.platform.atv'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    if xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    if xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def killxbmc():
    myplatform = get_platform()
    i = xbmcgui.Dialog().yesno('KODI BEENDEN', 'Sie sind dabei Kodi zu schlie\xc3\x9fen !', 'M\xc3\xb6chten Sie fortfahren ?', nolabel='NEIN', yeslabel='JA')
    if i < 1:
        sys.exit(0)
    if myplatform == 'osx':
        try:
            os.system('killall -9 Kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'linux':
        try:
            os.system('killall Kodi')
        except:
            pass
        try:
            os.system('killall -9 kodi.bin')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'android':
        try:
            os.system('adb shell am force-stop org.xbmc.kodi')
        except:
            pass
        try:
            os.system('adb shell am kill org.xbmc.kodi')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc16());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc17());')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_SETTINGS","","")')
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    else:
        try:
            os.system('killall AppleTV')
        except:
            pass
        try:
            os.system('sudo initctl stop kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    sys.exit(0)

def run(server_data_url):

    build_url = get_build_download_url(get_server_data(server_data_url),_sys_build_version_)

    _backup_zip_full_path_ = resume_download(build_url + password_settings,_backup_zip_path_)
    if not os.path.exists(_backup_zip_full_path_):sys.exit(0)
    xbmc.sleep(2000)

    _zip_file_ = check_zipfile(_backup_zip_full_path_)

    if _zip_file_ == 'No zip file !':
        delete_file(_backup_zip_full_path_)
        xbmcgui.Dialog().ok('ZIP FILE ERROR !',_zip_file_)
        sys.exit(0)

    if _addon_.getSetting('auto_clean_on_off') == 'true':
        clean_data(_home_path_,_addon_,_addon_id_)
        xbmc.sleep(2000)

    extract_zip(_zip_file_,_backup_zip_full_path_,_home_path_,_addon_,_addon_id_)
    xbmc.sleep(2000)

    if _addon_.getSetting('auto_clean_on_off') == 'false':
        wizard_activator(_database_path_,_home_path_,_sys_build_version_,_addon_id_)
        xbmc.sleep(2000)

    delete_file(_backup_zip_full_path_)
    xbmc.sleep(2000)
    killxbmc()